PREDICTOR 4.0 KEY PANEL - ANDROID PROJECT

This is an Android Studio project wrapper for the supplied HTML admin panel.
The original HTML is included at:
app/src/main/assets/index.html

BUILD APK:
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Open the extracted PredictorPanelAndroid folder in Android Studio.
4. Wait for Gradle sync to finish. Install Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the generated APK location (usually app/build/outputs/apk/debug/app-debug.apk).

NOTES:
- Internet permission is enabled because the HTML loads Firebase and external font/icon assets over HTTPS.
- JavaScript and DOM storage are enabled for the panel's existing web functionality.
- This project is source code, not a compiled APK. A computer with Android Studio/Android SDK is needed to build the APK.
- Test login, Firebase database access, and all admin actions before using the app.
